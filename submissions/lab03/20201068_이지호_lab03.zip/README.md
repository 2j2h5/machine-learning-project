# Lab 3 — K-means, GMM, and EM (20201068 이지호)

Reproduce `results.json` (Python 3.10, CPU only, runs in about 1 second):

```bash
pip install -r requirements.txt   # the course requirements file: numpy, matplotlib, pytest, jupyter
python src/lab03.py               # writes results.json (seed 42)
python -m pytest tests/ -q        # optional: public tests
```

Run these from the lab folder, which has `data/lab03_scene.npz` next to `src/`. The dataset is
not included in this zip, as the submission rules require.
